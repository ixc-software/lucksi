#!/bin/sh

export INSTALL_DIR=$1   # $1 - install dir
export SRC_DIR=$2       # $2 - source dir

cd $SRC_DIR

./bootstrap.sh
./b2 install --prefix=$INSTALL_DIR

