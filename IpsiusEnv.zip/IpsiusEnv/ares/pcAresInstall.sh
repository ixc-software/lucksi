#!/bin/sh

export INSTALL_DIR=$1	# $1 - install dir
export SRC_DIR=$2	# $2 - cares source dir


cd $SRC_DIR

./configure --prefix=$INSTALL_DIR --disable-debug

make
make install

