#!/bin/bash

# current qt version 4.7.4

export INSTALL_DIR=$1	# $1 - install dir
export SRC_DIR=$2	# $2 - qt source dir

cd $SRC_DIR

./configure -silent -opensource -confirm-license \
        -prefix $INSTALL_DIR \
	-nomake demos -nomake examples \
        -shared -largefile -no-qt3support \
        -no-webkit \
        -audio-backend -phonon -phonon-backend -fast

make
make install

