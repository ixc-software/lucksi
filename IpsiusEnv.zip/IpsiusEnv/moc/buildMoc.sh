#!/bin/sh

export QTDIR=$1			# $1 - path to installed QT
export QT_SOURCE=$2		# $2 - path to source QT
export IPSIUS_SOURCE=$3		# $3 - path to Ipsius source

cp $QTDIR/bin/moc $QTDIR/bin/moc_old

cd $IPSIUS_SOURCE/ProjMocExt-4.7.4
$QTDIR/bin/qmake ./moc.pro

make

cp ./bin/moc $QTDIR/bin



