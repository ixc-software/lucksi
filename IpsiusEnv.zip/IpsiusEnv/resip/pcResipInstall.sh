#!/bin/bash

export INSTALL_DIR=$1		# $1 - install dir
export BOOST_HEADERS=$2		# $2 - boost headers path
export DB4_HEADERS=$3		# $3 - db4 headers path
export CARES_HEADERS=$4		# $4 - cares headers path
export CARES_LIB=$5		# $5 - cares lib path

svn checkout https://svn.resiprocate.org/rep/resiprocate/main ./resiprocate

cd ./resiprocate

patch -p0 -i ../resip.patch

cd ./build
patch -p0 -i ../../db-5.2.patch
cd ..

./configure -y  \
        --with-compile-type=nodebug     \
        --enable-repro \
        --repro-db="berkeley-db4" \
        --db4-headers=$DB4_HEADERS \
        --boost-headers=$BOOST_HEADERS \
        --prefix=$INSTALL_DIR \
        --disable-ssl \
        --disable-dtls \
        --disable-popt \
        --with-resolver=c-ares  \
        --cares-headers=$CARES_HEADERS \
        --cares-libs=$CARES_LIB

make

make install
