#!/bin/sh

export INSTALL_DIR=$1   # $1 - install dir
export SRC_DIR=$2       # $2 - source dir

cd $SRC_DIR

./dist/configure --prefix=$INSTALL_DIR --enable-cxx

make
make install

