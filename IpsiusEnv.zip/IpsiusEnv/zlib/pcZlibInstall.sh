#!/bin/bash

export INSTALL_DIR=$1		# $1 - install dir
export INSTALL_HEADER=$2	# $2 - install headers dir
export ZLIB_SRC_DIR=$3       	# $3 - source dir
export QTDIR=$4			# qt install dir

export CURRENT_DIR=$PWD

#---------------------------------------------------------------------
# build zlib
cd $ZLIB_SRC_DIR
mkdir $INSTALL_DIR
./configure --prefix=$INSTALL_DIR --includedir=$OUTPUT_DIR/install/include/zlib

make
make install


#---------------------------------------------------------------------
# build unzip

cd $CURRENT_DIR
$QTDIR/bin/qmake -r unzip.pro -spec $QTSPEC 

make
make install

