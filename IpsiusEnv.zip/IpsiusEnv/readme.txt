    Build sequence
1. ares. c-ares is a C library that performs DNS requests and name resolves asynchronously. need for resip
2. boost
3. qt
4. moc. qt moc extension
5. db.  berkley db need for resip proxy
6. zlib.
7. resip. Sip stack. http://www.resiprocate.org

