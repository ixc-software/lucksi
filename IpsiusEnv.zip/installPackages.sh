#!/bin/sh

sudo apt-get install aptitude
sudo aptitude install -y mc
sudo aptitude install -y python3
sudo aptitude install -y build-essential
sudo aptitude install -y binutils-dev
sudo aptitude install -y git
sudo aptitude install -y subversion
sudo aptitude install -y subversion-tools
sudo aptitude install -y kdesvn
sudo aptitude install -y wget
sudo aptitude install -y libdb++-dev
sudo aptitude install -y libxext-dev
sudo aptitude install -y libgstreamer0.10-dev
sudo aptitude install -y libgstreamer-plugins-base0.10-dev
sudo aptitude install -y libxrender-dev
sudo aptitude install -y gcc-multilib
sudo aptitude install -y g++-multilib
sudo aptitude install -y bison
sudo aptitude install -y flex
sudo aptitude install -y texinfo
sudo aptitude install -y ncurses-dev

